"""
Utilities for MyAIChatBot
"""