"""
Core components of MyAIChatBot
"""