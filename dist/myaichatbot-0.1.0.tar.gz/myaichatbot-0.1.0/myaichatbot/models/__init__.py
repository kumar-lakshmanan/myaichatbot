"""
Models for MyAIChatBot
"""